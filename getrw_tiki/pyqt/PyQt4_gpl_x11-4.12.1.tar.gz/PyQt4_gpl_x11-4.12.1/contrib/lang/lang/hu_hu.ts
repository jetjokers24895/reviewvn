<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>Title</source>
        <translation type="unfinished">Cím</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Szöveg</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Nyelv</translation>
    </message>
</context>
</TS>
